from setuptools import setup

setup(
    name='search4letters',
    version='1.0',
    description='The Head First Python Search Tools',
    author='Pinkwitch13',
    author_email='pinkwitch13@pinkwitch13.com',
    py_modules=['search4letters'],
)
